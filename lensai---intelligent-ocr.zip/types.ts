export interface ExtractedRegion {
  type: 'header' | 'body' | 'table' | 'caption' | 'handwriting' | 'other';
  content: string;
  confidence: number;
}

export interface SemanticAnalysis {
  summary: string;
  keywords: string[];
  entities: string[];
  sentiment?: string;
}

export interface StructuredData {
  json_representation: Record<string, any>;
  csv_content?: string;
}

export interface AIAnalysisResult {
  task_understanding: {
    image_type: string;
    detected_languages: string[];
  };
  text_content: {
    full_text: string;
    regions: ExtractedRegion[];
  };
  semantic_analysis: SemanticAnalysis;
  structured_data: StructuredData;
  recommendations: string[];
}

export enum ViewMode {
  UPLOAD = 'UPLOAD',
  ANALYZING = 'ANALYZING',
  RESULT = 'RESULT',
  ERROR = 'ERROR'
}
