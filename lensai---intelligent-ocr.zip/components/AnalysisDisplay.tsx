import React, { useState } from 'react';
import { AIAnalysisResult } from '../types';
import { 
  FileText, 
  BrainCircuit, 
  CheckCircle2, 
  AlertCircle,
  Copy,
  ChevronRight,
  Sparkles
} from 'lucide-react';

interface AnalysisDisplayProps {
  result: AIAnalysisResult;
  imageUrl: string;
}

const TabButton: React.FC<{
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}> = ({ active, onClick, icon, label }) => (
  <button
    onClick={onClick}
    className={`
      flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all
      ${active 
        ? 'bg-brand-500 text-white shadow-lg shadow-brand-500/25' 
        : 'text-slate-400 hover:text-white hover:bg-slate-800'
      }
    `}
  >
    {icon}
    {label}
  </button>
);

export const AnalysisDisplay: React.FC<AnalysisDisplayProps> = ({ result, imageUrl }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'text'>('overview');
  const [copied, setCopied] = useState(false);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full max-w-7xl mx-auto flex flex-col lg:flex-row gap-6 h-[calc(100vh-140px)] animate-fade-in">
      {/* Left Panel: Image Preview & Quick Stats */}
      <div className="w-full lg:w-1/3 flex flex-col gap-4">
        <div className="bg-slate-800/50 rounded-xl border border-slate-700 overflow-hidden flex-1 relative group">
           <img 
            src={imageUrl} 
            alt="Analyzed" 
            className="w-full h-full object-contain bg-slate-900/50 p-4"
           />
           <div className="absolute top-2 right-2 bg-black/60 backdrop-blur text-xs px-2 py-1 rounded text-white border border-white/10">
              {result.task_understanding.image_type}
           </div>
        </div>
        
        <div className="bg-slate-800/50 rounded-xl border border-slate-700 p-5">
           <h3 className="text-sm font-semibold text-slate-300 mb-3 uppercase tracking-wider flex items-center gap-2">
             <BrainCircuit className="w-4 h-4 text-brand-500" /> Analysis Meta
           </h3>
           <div className="space-y-3">
              <div>
                <span className="text-xs text-slate-500 block">Detected Languages</span>
                <div className="flex gap-2 mt-1 flex-wrap">
                  {result.task_understanding.detected_languages.map(lang => (
                    <span key={lang} className="text-xs px-2 py-1 rounded bg-slate-700 text-slate-300 border border-slate-600">
                      {lang}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <span className="text-xs text-slate-500 block mb-1">Confidence Segments</span>
                <div className="h-2 w-full bg-slate-700 rounded-full overflow-hidden flex">
                  {result.text_content.regions.slice(0, 5).map((region, i) => (
                    <div 
                      key={i}
                      style={{ width: `${100 / Math.min(5, result.text_content.regions.length)}%`, opacity: 0.5 + (region.confidence * 0.5) }} 
                      className="h-full bg-brand-500 border-r border-slate-900 last:border-0"
                      title={`${region.type}: ${Math.round(region.confidence * 100)}%`}
                    />
                  ))}
                </div>
              </div>
           </div>
        </div>
      </div>

      {/* Right Panel: Content Tabs */}
      <div className="w-full lg:w-2/3 flex flex-col bg-slate-900 rounded-xl border border-slate-700 overflow-hidden shadow-2xl">
        {/* Tab Navigation */}
        <div className="flex items-center gap-2 p-4 border-b border-slate-800 bg-slate-900/50 backdrop-blur">
          <TabButton 
            active={activeTab === 'overview'} 
            onClick={() => setActiveTab('overview')} 
            icon={<Sparkles className="w-4 h-4" />} 
            label="Overview" 
          />
          <TabButton 
            active={activeTab === 'text'} 
            onClick={() => setActiveTab('text')} 
            icon={<FileText className="w-4 h-4" />} 
            label="Raw Text" 
          />
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-auto bg-slate-950 p-6 relative custom-scrollbar">
          
          {/* OVERVIEW TAB */}
          {activeTab === 'overview' && (
            <div className="space-y-8 animate-fade-in">
              <section>
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-brand-500" /> Semantic Summary
                </h3>
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-slate-300 leading-relaxed">
                  {result.semantic_analysis.summary || "No summary available."}
                </div>
              </section>

              <section className="grid md:grid-cols-2 gap-6">
                 <div>
                    <h4 className="text-sm font-medium text-slate-400 mb-3 uppercase tracking-wider">Keywords</h4>
                    <div className="flex flex-wrap gap-2">
                      {result.semantic_analysis.keywords?.map((kw, i) => (
                        <span key={i} className="px-3 py-1 rounded-full bg-slate-800 border border-slate-700 text-slate-300 text-sm hover:border-brand-500/50 transition-colors">
                          #{kw}
                        </span>
                      ))}
                    </div>
                 </div>
                 <div>
                    <h4 className="text-sm font-medium text-slate-400 mb-3 uppercase tracking-wider">Extracted Entities</h4>
                    <div className="space-y-2">
                      {result.semantic_analysis.entities?.slice(0, 6).map((ent, i) => (
                         <div key={i} className="flex items-center gap-2 text-sm text-slate-300">
                            <ChevronRight className="w-3 h-3 text-brand-500" /> {ent}
                         </div>
                      ))}
                      {(!result.semantic_analysis.entities || result.semantic_analysis.entities.length === 0) && (
                        <span className="text-sm text-slate-500 italic">No entities detected</span>
                      )}
                    </div>
                 </div>
              </section>

              {result.recommendations && result.recommendations.length > 0 && (
                <section className="bg-orange-500/10 border border-orange-500/20 rounded-xl p-4">
                   <h4 className="text-sm font-semibold text-orange-400 mb-2 flex items-center gap-2">
                     <AlertCircle className="w-4 h-4" /> AI Recommendations
                   </h4>
                   <ul className="list-disc list-inside text-sm text-orange-200/80 space-y-1">
                      {result.recommendations.map((rec, i) => (
                        <li key={i}>{rec}</li>
                      ))}
                   </ul>
                </section>
              )}
            </div>
          )}

          {/* RAW TEXT TAB */}
          {activeTab === 'text' && (
            <div className="h-full flex flex-col animate-fade-in">
               <div className="flex justify-between items-center mb-4">
                  <span className="text-xs text-slate-500 uppercase tracking-wider font-mono">
                    Character Count: {result.text_content.full_text.length}
                  </span>
                  <button 
                    onClick={() => handleCopy(result.text_content.full_text)}
                    className="flex items-center gap-1 text-xs text-brand-400 hover:text-brand-300"
                  >
                    {copied ? <CheckCircle2 className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    {copied ? 'Copied' : 'Copy Text'}
                  </button>
               </div>
               <textarea 
                  readOnly 
                  className="w-full h-full bg-slate-900 border border-slate-800 rounded-lg p-4 text-slate-300 font-mono text-sm leading-relaxed focus:outline-none focus:border-brand-500/50 resize-none"
                  value={result.text_content.full_text}
               />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};