import React, { useCallback, useState } from 'react';
import { UploadCloud, Image as ImageIcon, FileType } from 'lucide-react';

interface ImageUploaderProps {
  onFileSelect: (file: File) => void;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({ onFileSelect }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('image/')) {
        onFileSelect(file);
      }
    }
  }, [onFileSelect]);

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onFileSelect(e.target.files[0]);
    }
  }, [onFileSelect]);

  return (
    <div className="w-full max-w-2xl mx-auto mt-12 animate-fade-in-up">
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`
          relative group cursor-pointer
          border-2 border-dashed rounded-2xl p-12
          transition-all duration-300 ease-in-out
          flex flex-col items-center justify-center
          ${isDragging 
            ? 'border-brand-500 bg-brand-500/5 scale-[1.02]' 
            : 'border-slate-700 hover:border-brand-500/50 hover:bg-slate-800/50 bg-slate-800/20'
          }
        `}
      >
        <input
          type="file"
          accept="image/*"
          onChange={handleInputChange}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
        />
        
        <div className={`
          p-5 rounded-full mb-6 transition-all duration-300
          ${isDragging ? 'bg-brand-500 text-white shadow-lg shadow-brand-500/50' : 'bg-slate-800 text-brand-500'}
        `}>
          <UploadCloud className="w-10 h-10" />
        </div>

        <h3 className="text-xl font-semibold text-white mb-2">
          Upload Image to Analyze
        </h3>
        <p className="text-slate-400 text-center max-w-sm mb-6">
          Drag & drop your document, screenshot, or photo here.
          <br /> 
          <span className="text-xs opacity-70">Supports JPG, PNG, WEBP up to 10MB</span>
        </p>

        <div className="flex gap-4 text-xs text-slate-500 uppercase tracking-wider font-medium">
          <div className="flex items-center gap-1.5">
            <ImageIcon className="w-4 h-4" /> Photos
          </div>
          <div className="flex items-center gap-1.5">
            <FileType className="w-4 h-4" /> Scanned Docs
          </div>
          <div className="flex items-center gap-1.5">
            <FileType className="w-4 h-4" /> Handwriting
          </div>
        </div>
      </div>
    </div>
  );
};
