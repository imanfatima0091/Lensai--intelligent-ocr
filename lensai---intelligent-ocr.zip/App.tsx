import React, { useState } from 'react';
import { Header } from './components/Header';
import { ImageUploader } from './components/ImageUploader';
import { AnalysisDisplay } from './components/AnalysisDisplay';
import { analyzeImage } from './services/gemini';
import { fileToBase64 } from './utils/helpers';
import { AIAnalysisResult, ViewMode } from './types';
import { Loader2, AlertTriangle, RefreshCcw } from 'lucide-react';

export default function App() {
  const [viewMode, setViewMode] = useState<ViewMode>(ViewMode.UPLOAD);
  const [analysisResult, setAnalysisResult] = useState<AIAnalysisResult | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileSelect = async (file: File) => {
    try {
      setViewMode(ViewMode.ANALYZING);
      setError(null);
      
      // Create local preview URL
      const objectUrl = URL.createObjectURL(file);
      setSelectedImage(objectUrl);

      // Get Base64 for API
      const base64Data = await fileToBase64(file);
      
      // Analyze
      const result = await analyzeImage(base64Data, file.type);
      
      setAnalysisResult(result);
      setViewMode(ViewMode.RESULT);
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'An unexpected error occurred');
      setViewMode(ViewMode.ERROR);
    }
  };

  const resetApp = () => {
    setViewMode(ViewMode.UPLOAD);
    setAnalysisResult(null);
    setSelectedImage(null);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50 font-sans selection:bg-brand-500/30">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {viewMode === ViewMode.UPLOAD && (
          <div className="flex flex-col items-center justify-center min-h-[60vh]">
            <div className="text-center mb-8 space-y-4 animate-fade-in">
              <h2 className="text-4xl md:text-5xl font-bold tracking-tight text-white">
                Turn Images into <br />
                <span className="bg-gradient-to-r from-brand-400 to-emerald-400 bg-clip-text text-transparent">
                  Structured Intelligence
                </span>
              </h2>
              <p className="text-lg text-slate-400 max-w-2xl mx-auto">
                Upload scans, screenshots, or handwritten notes. Our AI extracts text, understands context, and creates structured data instantly.
              </p>
            </div>
            <ImageUploader onFileSelect={handleFileSelect} />
          </div>
        )}

        {viewMode === ViewMode.ANALYZING && (
          <div className="flex flex-col items-center justify-center min-h-[60vh] animate-fade-in">
            <div className="relative">
              <div className="absolute inset-0 bg-brand-500 blur-xl opacity-20 rounded-full animate-pulse"></div>
              <Loader2 className="w-16 h-16 text-brand-500 animate-spin relative z-10" />
            </div>
            <h3 className="text-xl font-medium text-white mt-8">Analyzing Document Structure...</h3>
            <p className="text-slate-400 mt-2 text-center max-w-md">
              Identifying regions, extracting text, and performing semantic analysis.
            </p>
          </div>
        )}

        {viewMode === ViewMode.RESULT && analysisResult && selectedImage && (
          <div className="animate-fade-in">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-2xl font-semibold text-white">Analysis Results</h2>
              <button 
                onClick={resetApp}
                className="flex items-center gap-2 text-sm text-slate-400 hover:text-white transition-colors"
              >
                <RefreshCcw className="w-4 h-4" /> Analyze Another
              </button>
            </div>
            <AnalysisDisplay result={analysisResult} imageUrl={selectedImage} />
          </div>
        )}

        {viewMode === ViewMode.ERROR && (
          <div className="flex flex-col items-center justify-center min-h-[60vh] animate-fade-in">
            <div className="bg-red-500/10 p-6 rounded-full mb-6">
              <AlertTriangle className="w-12 h-12 text-red-500" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Analysis Failed</h3>
            <p className="text-slate-400 max-w-md text-center mb-8">
              {error || "We couldn't process this image. Please ensure it's a valid image file and try again."}
            </p>
            <button
              onClick={resetApp}
              className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-lg font-medium transition-colors flex items-center gap-2"
            >
              <RefreshCcw className="w-4 h-4" /> Try Again
            </button>
          </div>
        )}
      </main>
    </div>
  );
}