import { GoogleGenAI, Type, Schema } from "@google/genai";
import { AIAnalysisResult } from "../types";

const SYSTEM_INSTRUCTION = `
You are **Image-to-Text AI**, a highly advanced system specializing in OCR, scene text extraction, handwriting recognition, and semantic analysis.

Your mission is to accurately extract, interpret, and structure all textual content from the provided image.

Perform the following steps:
1. **Image Analysis**: Detect text, tables, charts, languages, and image type (scanned, screenshot, handwriting, etc.).
2. **Text Extraction**: OCR all text. Identify regions (headers, body, etc.).
3. **Semantic Understanding**: Summarize content, extract keywords/entities.
4. **Structure**: Output clean JSON with key-value pairs for unstructured data and CSV for tabular data.
`;

const RESPONSE_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    task_understanding: {
      type: Type.OBJECT,
      properties: {
        image_type: { type: Type.STRING, description: "E.g., Scanned Document, Screenshot, Handwriting" },
        detected_languages: { type: Type.ARRAY, items: { type: Type.STRING } }
      }
    },
    text_content: {
      type: Type.OBJECT,
      properties: {
        full_text: { type: Type.STRING, description: "The complete extracted text combined." },
        regions: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              type: { type: Type.STRING, enum: ['header', 'body', 'table', 'caption', 'handwriting', 'other'] },
              content: { type: Type.STRING },
              confidence: { type: Type.NUMBER, description: "0.0 to 1.0" }
            }
          }
        }
      }
    },
    semantic_analysis: {
      type: Type.OBJECT,
      properties: {
        summary: { type: Type.STRING },
        keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
        entities: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Names, dates, locations, numbers" }
      }
    },
    structured_data: {
      type: Type.OBJECT,
      properties: {
        // Using a list of key-value pairs because Type.OBJECT cannot be empty in schema definition
        key_value_pairs: { 
            type: Type.ARRAY,
            description: "Extracted data fields as key-value pairs",
            items: {
                type: Type.OBJECT,
                properties: {
                    key: { type: Type.STRING },
                    value: { type: Type.STRING }
                }
            }
        },
        csv_content: { type: Type.STRING, description: "CSV formatted string if tabular data is detected, else empty string." }
      }
    },
    recommendations: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Suggestions for better image quality or confidence improvement."
    }
  },
  required: ["task_understanding", "text_content", "semantic_analysis", "structured_data"]
};

export const analyzeImage = async (base64Image: string, mimeType: string): Promise<AIAnalysisResult> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found in environment variables");
  }

  const ai = new GoogleGenAI({ apiKey });

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          { inlineData: { mimeType: mimeType, data: base64Image } },
          { text: "Analyze this image fully. Extract all text, detect structure, and provide semantic analysis." }
        ]
      },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: RESPONSE_SCHEMA,
        temperature: 0.1, // Low temperature for consistent structure
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    const rawResult = JSON.parse(text);

    // Transform key_value_pairs back to a simple object for the UI
    const json_representation: Record<string, any> = {};
    if (rawResult.structured_data?.key_value_pairs && Array.isArray(rawResult.structured_data.key_value_pairs)) {
        rawResult.structured_data.key_value_pairs.forEach((pair: any) => {
            if (pair.key) {
                json_representation[pair.key] = pair.value;
            }
        });
    }

    const finalResult: AIAnalysisResult = {
        ...rawResult,
        structured_data: {
            json_representation: json_representation,
            csv_content: rawResult.structured_data?.csv_content || ""
        }
    };

    return finalResult;
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
};